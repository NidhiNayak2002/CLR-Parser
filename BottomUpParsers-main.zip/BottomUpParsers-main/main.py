from functions import *
from tkinter import *
import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.geometry("500x500")
root.title("Bottom-Up Parsers")
root.config(bg='#D9D8D7')
style = ttk.Style(root)
frame = tk.Frame(root, padx=10,pady=10,bg='#D9D8D7')
frame.pack()


clr_btn = tk.Button(frame,width=20,font=('calibri', 20, 'bold'),bd=10,bg="#4a7abc",foreground = 'white smoke',text = "CLR Parser",command=call_clr,cursor="hand2")

exit_btn = tk.Button(frame,width=10,font=('calibri', 20, 'bold'),bd=10,bg="#D9290e",foreground = 'white smoke',text = "CLOSE",command=root.destroy,cursor="hand2")

tk.Label(frame,text="BOTTOM UP PARSERS",foreground="black",bg='#D9D8D7',pady=20,font=('ariel', 30, 'bold','underline')).pack()

clr_btn.pack()
tk.Label(frame,text=" ",bg='#D9D8D7').pack()

exit_btn.pack()


changeOnHover(clr_btn, "blue","#4a7abc")

changeOnHover(exit_btn, "red","#D9290e")

root.mainloop()